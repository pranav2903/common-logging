﻿namespace WorkerServiceOptions.Example;

public enum Priority
{
    Deferred = -1,
    Low,
    Medium,
    High,
    Extreme
}
